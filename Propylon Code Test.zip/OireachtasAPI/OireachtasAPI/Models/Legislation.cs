﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OireachtasAPI
{
    //CLASS FOR EACH AND EVERY COMPONENT IN THE LEGISLATION FILE.
    public class Legislation
    {
        public LegislationHead head { get; set; }
        public LegislationResult[] results { get; set; }
    }

    public class LegislationHead
    {
        public LegislationCounts counts { get; set; }
        public Daterange dateRange { get; set; }
        public string lang { get; set; }
    }

    public class LegislationCounts
    {
        public int billCount { get; set; }
        public int resultCount { get; set; }
    }

    public class LegislationResult
    {
        public Bill bill { get; set; }
        public Billsort billSort { get; set; }
        public string contextDate { get; set; }
    }

    public class Bill
    {
        public Act act { get; set; }
        public Amendmentlist[] amendmentLists { get; set; }
        public string billNo { get; set; }
        public string billType { get; set; }
        public string billTypeURI { get; set; }
        public string billYear { get; set; }
        public Debate[] debates { get; set; }
        public EventInfo[] events { get; set; }
        public DateTime lastUpdated { get; set; }
        public string longTitleEn { get; set; }
        public string longTitleGa { get; set; }
        public string method { get; set; }
        public string methodURI { get; set; }
        public Mostrecentstage mostRecentStage { get; set; }
        public Originhouse originHouse { get; set; }
        public string originHouseURI { get; set; }
        public Relateddoc[] relatedDocs { get; set; }
        public string shortTitleEn { get; set; }
        public string shortTitleGa { get; set; }
        public string source { get; set; }
        public string sourceURI { get; set; }
        public Sponsor[] sponsors { get; set; }
        public StageĪnfo[] stages { get; set; }
        public string status { get; set; }
        public string statusURI { get; set; }
        public string uri { get; set; }
        public Version[] versions { get; set; }
    }

    public class Amendmentlist
    {
        public AmendmentListInfo amendmentList { get; set; }
    }

    public class AmendmentListInfo
    {
        public AmendmentTypeUri amendmentTypeUri { get; set; }
        public ChamberInfo chamber { get; set; }
        public string date { get; set; }
        public Formats formats { get; set; }
        public string showAs { get; set; }
        public Stage stage { get; set; }
        public string stageNo { get; set; }
    }

    public class Debate
    {
        public ChamberInfo chamber { get; set; }
        public string date { get; set; }
        public string debateSectionId { get; set; }
        public string showAs { get; set; }
        public string uri { get; set; }
    }

    public class Billsort
    {
        public int? actNoSort { get; set; }
        public string actShortTitleEnSort { get; set; }
        public string actShortTitleGaSort { get; set; }
        public int? actYearSort { get; set; }
        public int billNoSort { get; set; }
        public string billShortTitleEnSort { get; set; }
        public string billShortTitleGaSort { get; set; }
        public int billYearSort { get; set; }
    }

    public class ChamberInfo
    {
        public string showAs { get; set; }
        public string uri { get; set; }
    }

    public class Act
    {
        public string actNo { get; set; }
        public string actYear { get; set; }
        public string dateSigned { get; set; }
        public string longTitleEn { get; set; }
        public string longTitleGa { get; set; }
        public string shortTitleEn { get; set; }
        public string shortTitleGa { get; set; }
        public string statutebookURI { get; set; }
        public string uri { get; set; }
    }

    public class Mostrecentstage
    {
        public Event _event { get; set; }
    }

    public class Event
    {
        public Chamber chamber { get; set; }
        public Date[] dates { get; set; }
        public House house { get; set; }
        public int progressStage { get; set; }
        public string showAs { get; set; }
        public bool stageCompleted { get; set; }
        public string stageOutcome { get; set; }
        public string stageURI { get; set; }
        public string uri { get; set; }
        public string eventURI { get; set; }
    }

    public class Chamber
    {
        public string chamberCode { get; set; }
        public string showAs { get; set; }
        public string uri { get; set; }
    }

    public class House
    {
        public string chamberCode { get; set; }
        public string chamberType { get; set; }
        public string houseCode { get; set; }
        public string houseNo { get; set; }
        public string showAs { get; set; }
        public string uri { get; set; }
    }

    public class Date
    {
        public string date { get; set; }
    }

    public class Originhouse
    {
        public string showAs { get; set; }
        public string uri { get; set; }
    }



    public class AmendmentTypeUri
    {
        public string uri { get; set; }
    }



    public class Formats
    {
        public Pdf pdf { get; set; }
        public object xml { get; set; }
    }

    public class Pdf
    {
        public string uri { get; set; }
    }

    public class Stage
    {
        public string showAs { get; set; }
        public string uri { get; set; }
    }

    public class EventInfo
    {
        public Event _event { get; set; }
    }

    public class Relateddoc
    {
        public RelatedDocInfo relatedDoc { get; set; }
    }

    public class RelatedDocInfo
    {
        public string date { get; set; }
        public string docType { get; set; }
        public FormatsInfo formats { get; set; }
        public string lang { get; set; }
        public string showAs { get; set; }
        public string uri { get; set; }
    }

    public class FormatsInfo
    {
        public Pdf pdf { get; set; }
        public object xml { get; set; }
    }

    public class Sponsor
    {
        public SponsorInfo sponsor { get; set; }
    }

    public class SponsorInfo
    {
        public As _as { get; set; }
        public By by { get; set; }
    }

    public class As
    {
        public string showAs { get; set; }
        public object uri { get; set; }
    }

    public class By
    {
        public string showAs { get; set; }
        public string uri { get; set; }
    }

    public class StageĪnfo
    {
        public Event _event { get; set; }
    }

    public class Version
    {
        public VersionInfo version { get; set; }
    }

    public class VersionInfo
    {
        public string date { get; set; }
        public string docType { get; set; }
        public FormatsInfo formats { get; set; }
        public string lang { get; set; }
        public string showAs { get; set; }
        public string uri { get; set; }
    }


}
