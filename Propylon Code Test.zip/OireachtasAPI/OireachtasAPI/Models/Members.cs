﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OireachtasAPI
{
    //CLASS FOR EACH AND EVERY COMPONENT IN THE MEMBER FILE.
    public class Members
    {
        public Head head { get; set; }
        public Result[] results { get; set; }
    }

    public class Head
    {
        public Counts counts { get; set; }
        public Daterange dateRange { get; set; }
        public string lang { get; set; }
    }

    public class Counts
    {
        public int memberCount { get; set; }
        public int resultCount { get; set; }
    }

    public class Daterange
    {
        public DateTime start { get; set; }
        public DateTime end { get; set; }
    }

    public class Result
    {
        public Member member { get; set; }
    }

    public class Member
    {
        public string memberCode { get; set; }
        public string lastName { get; set; }
        public string firstName { get; set; }
        public string gender { get; set; }
        public object dateOfDeath { get; set; }
        public string fullName { get; set; }
        public string pId { get; set; }
        public object wikiTitle { get; set; }
        public string uri { get; set; }
        public Membership[] memberships { get; set; }
    }

    public class Membership
    {
        public MembershipInfo membership { get; set; }
    }

    public class MembershipInfo
    {
        public Represent[] represents { get; set; }
        public DateRange dateRange { get; set; }
        public Office[] offices { get; set; }
        public Party[] parties { get; set; }
        public string uri { get; set; }
        public House house { get; set; }
    }

    public class DateRange
    {
        public string start { get; set; }
        public string end { get; set; }
    }

    public class Represent
    {
        public RepresentInfo represent { get; set; }
    }

    public class RepresentInfo
    {
        public string representCode { get; set; }
        public string showAs { get; set; }
        public string uri { get; set; }
        public string representType { get; set; }
    }

    public class Office
    {
        public OfficeInfo office { get; set; }
    }

    public class OfficeInfo
    {
        public Officename officeName { get; set; }
        public DateRange dateRange { get; set; }
    }

    public class Officename
    {
        public string showAs { get; set; }
        public object uri { get; set; }
    }

    public class Party
    {
        public PartyInfo party { get; set; }
    }

    public class PartyInfo
    {
        public string showAs { get; set; }
        public DateRange dateRange { get; set; }
        public string partyCode { get; set; }
        public string uri { get; set; }
    }
}
