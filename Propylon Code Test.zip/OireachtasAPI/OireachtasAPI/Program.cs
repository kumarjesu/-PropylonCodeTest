﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace OireachtasAPI
{
    public class Program
    {

        static void Main(string[] args)
        {
            List<Bill> bills = new List<Bill>();
            List<dynamic> offline_bills = new List<dynamic>();

            try
            {
                /// USER HAS TO ENTER THE OPTION AS BELOW
                ///     O / o FOR OFFLINE DATA
                ///     a / A FOR ONLINE DATA (LIVE DATA FROM API)
                ///     D / d FOR DATA BETWEEN THE START DATE AND END DATE
                Console.WriteLine("Please Enter the Option : (O for Offline Data || A for Uptodate API Feed Data || D for Start and End Date Data) : ");
                string fileOption = Console.ReadLine();
                
                /// IF ITS FIRST OPTION - O /o THIS WILL USE THE OFFLINE JSON FILE
                if (fileOption.ToUpper().Equals("O"))
                {
                    Console.WriteLine("Please Enter the PID Value : ");
                    string pidVal = Console.ReadLine();
                    offline_bills = DataProcess.filterBillsSponsoredBy_offline(pidVal);
                    if (offline_bills.Count > 0)
                    {
                        Console.WriteLine("No of Records Found for pId (" + pidVal + ")" + " : " + offline_bills.Count);
                    }
                    else
                    {
                        Console.WriteLine("!!!!!! No Records Found !!!!!!");
                    }
                }
                /// IF ITS FIRST OPTION - A /a THIS WILL USE THE ONLINE DATA FROM API
                else if (fileOption.ToUpper().Equals("A"))
                {
                    Console.WriteLine("Please Enter the PID Value");
                    string PId = Console.ReadLine();
                    bills = DataProcess.filterBillsSponsoredBy_online(PId);

                    /// TO CONVERT THE DATA FROM List<Bills> to List<Dynamic>
                    List<dynamic> online_bills = new List<dynamic>();
                    online_bills = bills.Cast<dynamic>().ToList();

                    if (bills.Count > 0)
                    {
                        Console.WriteLine("No of Records Found for pId (" + PId + ")" + " : " + bills.Count);
                    }
                    else
                    {
                        Console.WriteLine("!!!!!! No Records Found !!!!!!");
                    }
                }
                /// IF ITS FIRST OPTION - D / d THEN
                ///     THERE WILL BE 2 OPTION 
                ///         O / o FOR OFFLINE DATA 
                ///         A / A FOR LIVE DATA
                else if (fileOption.ToUpper().Equals("D"))
                {
                    Console.WriteLine("Please provide the Date criteria -Start Date as dd-mm-yyyy format");
                    DateTime startDate = DateTime.Parse(Console.ReadLine());
                    Console.WriteLine("Please provide the Date criteria -End Date as dd-mm-yyyy format");
                    DateTime endDate = DateTime.Parse(Console.ReadLine());
                    if (endDate.Equals(null))
                    {
                        endDate = DateTime.Now;
                    }

                    Console.WriteLine("Please Confirm O for Offline || L for Live API... ");
                    string dataOption = Console.ReadLine();

                        if (dataOption.ToUpper().Equals("O"))
                        {
                            bills = DataProcess.filterBillsByLastUpdated_offline(startDate, endDate);
                        }
                        else if (dataOption.ToUpper().Equals("L"))
                        {
                            bills = DataProcess.filterBillsByLastUpdated_online(startDate, endDate);
                        }
                        else
                        {
                            Console.WriteLine("Invalid Option");
                        }

                    if (bills.Count > 0)
                    {
                        Console.WriteLine("No of Records found between Start Date (" + startDate + ") and End Date (" + endDate +") are " + " : " + bills.Count);
                    }
                    else
                    {
                        Console.WriteLine("!!!!!! No Records Found !!!!!!");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Message : ", ex.Message);
            }

            Console.ReadKey();

        }
    }
}
