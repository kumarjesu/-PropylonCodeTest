﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace OireachtasAPI
{
    class HttpClientRepository
    {
        private readonly HttpClient client = new HttpClient();
        private readonly string baseURL;

        public HttpClientRepository(string url)
        {
            baseURL = url;
        }

        public async Task<T> GetAsync<T>()
        {
            HttpResponseMessage response = await client.GetAsync(baseURL);
            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"{response.StatusCode}: {response.ReasonPhrase}");
            }

            string responseObject = await response.Content.ReadAsStringAsync();
            T data = JsonConvert.DeserializeObject<T>(responseObject);
            return data;
        }

    }
}
