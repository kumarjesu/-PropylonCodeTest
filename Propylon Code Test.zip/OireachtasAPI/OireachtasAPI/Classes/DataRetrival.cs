﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OireachtasAPI
{
    public static class DataRetrival
    {
        /// RETRIEVE THE ONLINE DATA USING HTTP CLIENT FOR MEMBERS 
        public static Members LoadMember()
        {
            HttpClientRepository clientRepository = new HttpClientRepository("https://api.oireachtas.ie/v1/members");
            Members member = clientRepository.GetAsync<Members>().Result;
            return member;
        }

        /// RETRIEVE THE ONLINE DATA USING HTTP CLIENT FOR LEGISLATION
        public static Legislation LoadLegislation()
        {
            HttpClientRepository clientRepository = new HttpClientRepository("https://api.oireachtas.ie/v1/legislation");
            Legislation legislation = clientRepository.GetAsync<Legislation>().Result;
            return legislation;
        }

        /// RETRIEVE THE OFFLINE DATA USING HTTP CLIENT FOR LEGISLATION
        public static Legislation LoadLegislationJson()
        {
            Legislation legislation;
            using (System.IO.StreamReader r = new System.IO.StreamReader(OireachtasAPI.DataProcess.LEGISLATION_DATASET))
            {
                string json = r.ReadToEnd();
                legislation = JsonConvert.DeserializeObject<Legislation>(json);
            }
            return legislation;
        }

        /// RETRIEVE THE OFFLINE DATA USING HTTP CLIENT FOR MEMBERS 
        public static Members LoadMemberJson()
        {
            Members members;
            using (System.IO.StreamReader r = new System.IO.StreamReader(OireachtasAPI.DataProcess.MEMBERS_DATASET))
            {
                string json = r.ReadToEnd();
                members = JsonConvert.DeserializeObject<Members>(json);
            }
            return members;
        }

    }
}
