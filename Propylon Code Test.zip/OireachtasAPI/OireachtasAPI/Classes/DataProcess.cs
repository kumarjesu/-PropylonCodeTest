﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OireachtasAPI
{
    public static class DataProcess
    {
        public static string LEGISLATION_DATASET = "legislation.json";
        public static string MEMBERS_DATASET = "members.json";

        /// <summary>
        /// Return bills sponsored by the member with the specified pId
        /// </summary>
        /// <param name="pId">The pId value for the member</param>
        /// <returns>List of bill records</returns>
        /// OFFLINE DATA (JSON) FILE
        public static Func<string, dynamic> load = jfname => JsonConvert.DeserializeObject((new System.IO.StreamReader(jfname)).ReadToEnd());

        public static List<dynamic> filterBillsSponsoredBy_offline(string pId)
        {
            dynamic leg = load(LEGISLATION_DATASET);
            dynamic mem = load(MEMBERS_DATASET);
            List<dynamic> ret = new List<dynamic>();

            try
            {
                foreach (dynamic res in leg["results"])
                {
                    dynamic p = res["bill"]["sponsors"];
                    foreach (dynamic i in p)
                    {
                        string name = i["sponsor"]["by"]["showAs"];
                        foreach (dynamic result in mem["results"])
                        {
                            string fname = result["member"]["fullName"];
                            string rpId = result["member"]["pId"];
                            if (fname == name && rpId == pId)
                            {
                                ret.Add(res["bill"]);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Message : " + ex);
            }
            return ret;
        }

        /// <summary>
        /// Return bills sponsored by the member with the specified pId
        /// Used List<Bill> instead of List<Dynamic>
        /// </summary>
        /// <param name="pId">The pId value for the member</param>
        /// <returns>List of bill records</returns>
        /// LIVE API DATA
        public static List<Bill> filterBillsSponsoredBy_online(string pId)
        {
            Members member = OireachtasAPI.DataRetrival.LoadMember();
            Legislation legislation = OireachtasAPI.DataRetrival.LoadLegislation(); 
            List<Bill> bills = new List<Bill>();
            try
            {
                int legCnt = legislation.results.Length;
                for (int l = 0; l < legCnt; l++)
                {
                    int bilCnt = legislation.results[l].bill.sponsors.Length;
                    for (int s = 0; s < bilCnt; s++)
                    {
                        string name = legislation.results[l].bill.sponsors[s].sponsor.by.showAs;
                        if (member.results.Any(r => r.member.fullName == name && r.member.pId == pId))
                        {
                            bills.Add(legislation.results[l].bill);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Message : " + ex.Message);
            }
            return bills;
        }

        /// <summary>
        /// Return bills updated within the specified date range
        /// </summary>
        /// <param name="since">The lastUpdated value for the bill should be greater than or equal to this date</param>
        /// <param name="until">The lastUpdated value for the bill should be less than or equal to this date.If unspecified, until will default to today's date</param>
        /// <returns>List of bill records</returns>
        /// OFFLINE JSON FILE OUTPUT
        public static List<Bill> filterBillsByLastUpdated_offline(DateTime since, DateTime until)
        {
            List<Bill> bills = new List<Bill>();
            try
            {
                Legislation legislation = DataRetrival.LoadLegislationJson();
                Members member = DataRetrival.LoadMemberJson();

                for (int l = 0; l < legislation.results.Length; l++)
                {
                    DateTime lUpDate = legislation.results[l].bill.lastUpdated;

                    int stDate = since.CompareTo(lUpDate);
                    int unDate = until.CompareTo(lUpDate);

                    if (stDate == -1 && unDate == 1)
                    {
                        bills.Add(legislation.results[l].bill);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Error : " + ex.Message);
            }
            return bills;
        }

        /// <summary>
        /// Return bills updated within the specified date range
        /// </summary>
        /// <param name="since">The lastUpdated value for the bill should be greater than or equal to this date</param>
        /// <param name="until">The lastUpdated value for the bill should be less than or equal to this date.If unspecified, until will default to today's date</param>
        /// <returns>List of bill records</returns>
        /// LIVE API DATA OUTPUT
        public static List<Bill> filterBillsByLastUpdated_online(DateTime since, DateTime until)
        {
            List<Bill> bills = new List<Bill>();
            try
            {
                Members member = DataRetrival.LoadMember();
                Legislation legislation = DataRetrival.LoadLegislation();

                for (int l = 0; l < legislation.results.Length; l++)
                {
                    DateTime lUpDate = legislation.results[l].bill.lastUpdated;

                    int stDate = since.CompareTo(lUpDate);
                    int unDate = until.CompareTo(lUpDate);

                    if (stDate == -1 && unDate == 1)
                    {
                        bills.Add(legislation.results[l].bill);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Error : " + ex.Message);
            }
            return bills;
        }
    }
}
